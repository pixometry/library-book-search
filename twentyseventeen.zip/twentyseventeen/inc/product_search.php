<?php

add_action('wp_ajax_woo_product_search','woo_product_search_fn');
add_action('wp_ajax_nopriv_woo_product_search','woo_product_search_fn');

function woo_product_search_fn(){

	$data = $_POST['data'];

	$query_text = sanitize_text_field($data['query_text']);
	$per_page = sanitize_text_field($data['per_page']);

	if(!check_ajax_referer('submited-data','security')){

		wp_send_json('some problem');
		die();
	} 

	// Query Arguments
	$args = array(
		'post_type' => array('product'),
		'post_status' => array('publish'),
		'posts_per_page' => $per_page,
		's' => $query_text,
		'order' => 'DESC',
	);

	// The Query
	$product_search = new WP_Query( $args );

	// The Loop
	if ( $product_search->have_posts() ) {

		$response = '<div class="search_results">';

		while ( $product_search->have_posts() ) {
			$product_search->the_post();
				
			$response .= '<div class="search_result"><a href="'.get_the_permalink().'"><img src="'.get_the_post_thumbnail_url(get_the_ID(),"thumbnail").'" alt="" /><h6>'.get_the_title().'</h6></a></div>';
		}
		$response .= '</div>';
	} else {
		$response .= 'No Product Data Found';
	}

	/* Restore original Post Data */
	wp_reset_postdata();

	wp_send_json($response);
	die();
}