<?php
/**
 * Twenty Seventeen back compat functionality
 *
 * woocommerce product custom widget search 
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since Twenty Seventeen 1.0
 */


/**
* Adds product search widget
*/
class Productsearch_Widget extends WP_Widget {

	/**
	* Register widget with WordPress
	*/
	function __construct() {
		parent::__construct(
			'productsearch_widget', // Base ID
			esc_html__( 'custom product search', 'twentyseventeen' ), // Name
			array( 'description' => esc_html__( 'custom widget for product search', 'twentyseventeen' ), ) // Args
		);
	}

	/**
	* Front-end display of widget
	*/
	public function widget( $args, $instance ) {

		echo $args['before_widget'];

		// Output widget title
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}

		// Output generated fields
		$num_of_product_per_page = ($instance['num_of_product_per_page'])?$instance['num_of_product_per_page']:5;
		//$unique_id = esc_attr( uniqid( 'product-search-form-' ) );
		echo $widget_form_content .='<label for="product-search-form"><span class="screen-reader-text">'.__( 'Product Search for:', 'label', 'twentyseventeen' ).'</span></label><input type="text" id="product-search-form" class="search-field" placeholder="Search You Want..." value="" name="s" /><input type="hidden" id="num_of_product_per_page"  value="'.$num_of_product_per_page.'" name="num_of_product_per_page" /><div class="search_result_wrap"></div>';
		
		echo $args['after_widget'];
	}

	

	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'twentyseventeen' );

		$num_of_product_per_page = ! empty( $instance['num_of_product_per_page'] ) ? $instance['num_of_product_per_page'] : 5;

		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'twentyseventeen' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'num_of_product_per_page' ) ); ?>"><?php esc_attr_e( 'Number Of Product:', 'twentyseventeen' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'num_of_product_per_page' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'num_of_product_per_page' ) ); ?>" type="number" value="<?php echo esc_attr( $num_of_product_per_page ); ?>">
		</p>
		<?php
		
	}

	/**
	* Sanitize widget form values as they are saved
	*/
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		$instance['num_of_product_per_page'] = ( ! empty( $new_instance['num_of_product_per_page'] ) ) ? strip_tags( $new_instance['num_of_product_per_page'] ) : 5;
		
		return $instance;
	}
} // class Productsearch_Widget

// register product search widget
function register_productsearch_widget() {
	register_widget( 'Productsearch_Widget' );
}
add_action( 'widgets_init', 'register_productsearch_widget' );