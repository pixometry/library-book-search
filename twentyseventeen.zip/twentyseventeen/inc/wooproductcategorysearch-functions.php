<?php
/**
 * Twenty Seventeen back compat functionality
 *
 * woocommerce product custom widget for category search 
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since Twenty Seventeen 1.0
 */


/**
* Adds product search widget
*/
class Productcategorysearch_Widget extends WP_Widget {

	/**
	* Register widget with WordPress
	*/
	function __construct() {
		parent::__construct(
			'productcategorysearch_widget', // Base ID
			esc_html__( 'product category search', 'twentyseventeen' ), // Name
			array( 'description' => esc_html__( 'custom widget for product category search', 'twentyseventeen' ), ) // Args
		);
	}

	
	/**
	* Front-end display of widget
	*/
	public function widget( $args, $instance ) {

		global $wp_query;

		$is_pro_cat_page = $wp_query->query_vars['product_cat'];

		if($is_pro_cat_page){

			$pro_category = get_term_by('name',$is_pro_cat_page,'product_cat');
			$pro_cat_id = $pro_category->term_id;
			$pro_cat_name = $pro_category->name;

			$is_archive = '<input type="hidden" id="prod_is_archive" value="'.$pro_cat_id.'">';
		}else{

			$is_archive = '<input type="hidden" id="prod_is_archive" value="0">';
		}

		if($is_pro_cat_page){

			$pro_category = get_term_by('name',$is_pro_cat_page,'product_cat');
			$pro_cat_id = $pro_category->term_id;
			$pro_cat_name = $pro_category->name;
			$protermchildren = get_term_children( $pro_cat_id, 'product_cat' );

			if(count($protermchildren)){
				$widget_content ='';
				$widget_content .='<ul class="pro_cat_list">';

				foreach ($protermchildren as $protermchild) {

					$pro_term = get_term_by('id',$protermchild,'product_cat');
					//print_r($pro_term);
					$widget_content .='<li><input class="pro_cat" type="checkbox" value="'.$pro_term->term_id.'"><a href="#" title="'.$pro_term->name.'">'.$pro_term->name.'</a><span>('.$pro_term->count.')</span></li>';

				}
				$widget_content .='</ul>'.$is_archive;
			}else{

				$terms = get_terms( array(

					'taxonomy' => 'product_cat',
			        'hide_empty' => 0,
			        
			    ));

				if(count($terms)){

					$widget_content .='<ul class="pro_cat_list">';

					foreach ($terms as $term) {
					
					$widget_content .='<li><input class="pro_cat" type="checkbox" value="'.$term->term_id.'"><a href="#" title="'.$term->name.'">'.$term->name.'</a><span>('.$term->count.')</span></li>';						 

					}

					$widget_content .='</ul>'.$is_archive;

				}

			}
			

		}else{

			$terms = get_terms( array(

					'taxonomy' => 'product_cat',
			        'hide_empty' => 0,
			        
			    ));

				if(count($terms)){

					$widget_content .='<ul class="pro_cat_list">';

					foreach ($terms as $term) {
					
					$widget_content .='<li><input class="pro_cat" type="checkbox" value="'.$term->term_id.'"><a href="#" title="'.$term->name.'">'.$term->name.'</a><span>('.$term->count.')</span></li>';						 

					}

					$widget_content .='</ul>';

				}
			
		}

		echo $args['before_widget'];

		// Output widget title
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}


		// Output generated fields
		echo $widget_content;
		
		echo $args['after_widget'];
	}

	

	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'twentyseventeen' );

		$num_of_product_per_page = ! empty( $instance['num_of_product_per_page'] ) ? $instance['num_of_product_per_page'] : esc_html__( '', 'twentyseventeen' );

		?>

		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'twentyseventeen' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

	   <?php
		
	}

	/**
	* Sanitize widget form values as they are saved
	*/
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}
} // class Productcategorysearch_Widget

// register product category search widget
function register_productcategorysearch_widget() {
	register_widget( 'Productcategorysearch_Widget' );
}
add_action( 'widgets_init', 'register_productcategorysearch_widget' );