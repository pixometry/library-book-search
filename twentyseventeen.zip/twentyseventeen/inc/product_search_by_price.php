<?php


add_action('wp_ajax_woo_product_search_by_price_filter','woo_product_search_by_price_filter_fn');
add_action('wp_ajax_nopriv_woo_product_search_by_price_filter','woo_product_search_by_price_filter_fn');

function woo_product_search_by_price_filter_fn(){

	$data = $_POST['data'];

	$minpricedata = sanitize_text_field($data['minpricedata']);
	$maxpricedata = sanitize_text_field($data['maxpricedata']);
	$prod_is_archive = sanitize_text_field($data['prod_is_archive']);
	$selectCatVal = sanitize_text_field($data['selectCatVal']);
	

	if(!check_ajax_referer('submited-data','security')){

		wp_send_json('some problem');
		die();
	}

	// Query Arguments
	$args = array(
		'post_type' => array('product'),
		'post_status' => array('publish'),
		'posts_per_page' =>10,
		'order' => 'DESC',
		'meta_query'=>array(

			array(

				'key' => '_price',
				'value' => $minpricedata,
				'compare' => '>=',
				'type' =>'numeric'
			),
			array(

				'key' => '_price',
				'value' => $maxpricedata,
				'compare' => '<=',
				'type' =>'numeric'
			),
		),
		
	);

	if($prod_is_archive==0){

		//IF SHOP PAGE
		if($selectCatVal != 'empty'){

			$args['tax_query'] = array(

				array(

					'taxonomy'=>'product_cat',
					'field'=> 'term_id',
					'terms'=> explode(",",$selectCatVal),
					'operator'=>'IN',

				)
			);
		}

	}else{

		//PRODUCT CATEGORY PAGE	
		if($selectCatVal == 'empty'){

			$args['tax_query'] = array(

				array(

					'taxonomy'=>'product_cat',
					'field'=> 'term_id',
					'terms'=> array($prod_is_archive),
					'operator'=>'IN',

				)
			);
		}else{

			$args['tax_query'] = array(

				array(

					'taxonomy'=>'product_cat',
					'field'=> 'term_id',
					'terms'=> explode(",",$selectCatVal),
					'operator'=>'IN',

				)
			);

		}	
	}

	// The Query
	$product_searchbyprice = new WP_Query( $args );

	// The Loop
	if ( $product_searchbyprice->have_posts() ) {
		while ( $product_searchbyprice->have_posts() ) {
			$product_searchbyprice->the_post();
				
				wc_get_template_part('content','product');
		}
	} else {
		
		wp_send_json('No Product data Found');
	}

	wp_reset_query();
	/* Restore original Post Data */
	wp_reset_postdata();

	die();
}