<?php

/**
* Adds product price filter widget
*/
class Productpricefilter_Widget extends WP_Widget {

	/**
	* Register widget with WordPress
	*/
	function __construct() {
		parent::__construct(
			'productpricefilter_widget', // Base ID
			esc_html__( 'product price filter', 'twentyseventeen' ), // Name
			array( 'description' => esc_html__( 'woo commerce product price filter', 'twentyseventeen' ), ) // Args
		);
	}

	
	/**
	* Front-end display of widget
	*/
	public function widget( $args, $instance ) {

		global $wp_query;

		$is_pro_cat_page = $wp_query->query_vars['product_cat'];

		if($is_pro_cat_page){

			$pro_category = get_term_by('name',$is_pro_cat_page,'product_cat');
			$pro_cat_id = $pro_category->term_id;
			$pro_cat_name = $pro_category->name;

			$is_archive = '<input type="hidden" id="prod_is_archive" value="'.$pro_cat_id.'">';
		}else{

			$is_archive = '<input type="hidden" id="prod_is_archive" value="0">';
		}	

		echo $args['before_widget'];

		// Output widget title
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
		?>
		<div class="price-range-block">
	
			<div id="slider-range" class="price-filter-range" name="rangeInput"></div>

			<div style="margin:30px auto">
			  <input type="number" min=0 max="9900" oninput="validity.valid||(value='0');" id="min_price" class="price-range-field" />
			  <input type="number" min=0 max="10000" oninput="validity.valid||(value='10000');" id="max_price" class="price-range-field" />
			  <?php echo $is_archive; ?>
			</div>

			<button class="price-range-search" id="price-range-submit">Search</button>

			<div id="searchResults" class="search-results-block"></div>

		</div>
		<?php	
		// Output generated fields
		//echo '<p>'.$instance['prod_price_filter'].'</p>';
		
		echo $args['after_widget'];
	}

	

	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'twentyseventeen' );
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'twentyseventeen' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php
		
	}

	/**
	* Sanitize widget form values as they are saved
	*/
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		
		return $instance;
	}
} // class Productpricefilter_Widget

// register product price filter widget
function register_productpricefilter_widget() {
	register_widget( 'Productpricefilter_Widget' );
}
add_action( 'widgets_init', 'register_productpricefilter_widget' );