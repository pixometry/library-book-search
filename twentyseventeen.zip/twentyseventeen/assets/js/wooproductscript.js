/**
 * product search functionality
 */
jQuery(document).ready(function($){

  var productsearchprocess = function(formdata,action){

    $.ajax({

      url:productobj.ajaxurl,
      type:'POST',
      data:{

        action:action,
        data:formdata,
        security:productobj.security

      },
      success: function(response){

        $('.search_result_wrap').html(response);

      },
      error: function(){

        console.log('some problem');

      }

    });

  };

  $('#product-search-form').keyup(function(){

    $(document).trigger('productSearch');

  });

  $('#product-search-form').keydown(function(){

    $(document).trigger('productSearch');
    
  });


  $(document).on('productSearch',function(){

    var searchval = $('#product-search-form').val();

    if(searchval.length > 2){

      $('.search_result_wrap').html('<div class="spinner_wrap"><i class="fa fa-spinner faa-spin animated faa-spin animated-hover faa-spin pro_search_spin" aria-hidden="true"></i></div>');

      var searchdata = {
          'query_text': searchval,
          'per_page'  : $('#num_of_product_per_page').val()
      };

      productsearchprocess(searchdata,'woo_product_search');

    }

  });

  $(document).on('click','.site',function(){

    $('.search_results').slideUp();

  });

  $(document).on('click','.widget_productsearch_widget',function(e){

    e.stopPropagation();
    
  });

});

/**
 * product price filter slider code
 */

jQuery(document).ready(function($){
  
  jQuery('#price-range-submit').hide();

  jQuery("#min_price,#max_price").on('change', function () {

    jQuery('#price-range-submit').show();

    var min_price_range = parseInt(jQuery("#min_price").val());

    var max_price_range = parseInt(jQuery("#max_price").val());

    if (min_price_range > max_price_range) {
    jQuery('#max_price').val(min_price_range);
    }

    jQuery("#slider-range").slider({
    values: [min_price_range, max_price_range]
    });
    
  });


  jQuery("#min_price,#max_price").on("paste keyup", function () {                                        

    jQuery('#price-range-submit').show();

    var min_price_range = parseInt(jQuery("#min_price").val());

    var max_price_range = parseInt(jQuery("#max_price").val());
    
    if(min_price_range == max_price_range){

      max_price_range = min_price_range + 2;
      
      jQuery("#min_price").val(min_price_range);   
      jQuery("#max_price").val(max_price_range);
    }

    jQuery("#slider-range").slider({
    values: [min_price_range, max_price_range]
    });

  });


  jQuery(function ($) {
    jQuery("#slider-range").slider({
    range: true,
    orientation: "horizontal",
    min: 0,
    max: 100,
    values: [0, 100],
    step: 2,

    slide: function (event, ui) {
      if (ui.values[0] == ui.values[1]) {
        return false;
      }
      
      jQuery("#min_price").val(ui.values[0]);
      jQuery("#max_price").val(ui.values[1]);
    }
    });

    jQuery("#min_price").val(jQuery("#slider-range").slider("values", 0));
    jQuery("#max_price").val(jQuery("#slider-range").slider("values", 1));

  });

  jQuery("#slider-range,#price-range-submit").click(function () {

    var min_price = jQuery('#min_price').val();
    var max_price = jQuery('#max_price').val();

    jQuery("#searchResults").text("Here List of products will be shown which are cost between " + min_price  +" "+ "and" + " "+ max_price + ".");
  });

});

/**
 * product search by price filter code
 */

 jQuery(document).ready(function($){

    var productsearchbypricefilterprocess = function(formdata,action){

          $.ajax({

            url:productobj.ajaxurl,
            type:'POST',
            data:{

              action:action,
              data:formdata,
              security:productobj.security

            },
            success: function(response){

              $('ul.products').html(response);

            },
            error: function(){

              console.log('some problem');

            }

          });

      };

      

      $(document).on('productSearchBypriceFilter',function(){

        $('ul.products').html('<div class="spinner_wrap_price"><i class="fa fa-spinner faa-spin animated faa-spin animated-hover faa-spin pro_search_spin" aria-hidden="true"></i></div>');

        var selectCatArrayData = [];
        var item = 0;

        $('.pro_cat_list li .pro_cat').each(function(){

            if($(this).is(':checked')){

              selectCatArrayData[item] = $(this).val();

              item++;

            }
        });

        if(selectCatArrayData.length==0){

          var selectCatVal = 'empty';

        }else{

           var selectCatVal = selectCatArrayData.join(',');

        }
          var searchdata = {
              'minpricedata': $('#min_price').val(),
              'maxpricedata'  : $('#max_price').val(),
              'prod_is_archive': $('#prod_is_archive').val(),
              'selectCatVal': selectCatVal
          };

          productsearchbypricefilterprocess(searchdata,'woo_product_search_by_price_filter');

        
      });

      jQuery("#slider-range").slider({

        stop: function(event,ui){

          $(document).trigger('productSearchBypriceFilter');

        }

      });

      /**
       * product search by category code
       */

       $('.pro_cat_list li .pro_cat').on('click',function(){

          $(document).trigger('productSearchBypriceFilter');

       });

 });

