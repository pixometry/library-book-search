<?php
if($_REQUEST['param'] == 'save_book'){

		$wpdb->insert(my_books_table(),
			array(

				'name'=>$_REQUEST['txtName'],
				'author'=>$_REQUEST['txtAuthor'],
				'about'=>$_REQUEST['txtAbout'],
				'book_image'=>$_REQUEST['image_name']
			)
		);

		echo json_encode(array('status'=>1,'message'=>'Book created sucessfully'));
	}
	elseif ($_REQUEST['param'] == 'edit_book') {
		
		$wpdb->update(

			my_books_table(),

			array(

				'name'=>$_REQUEST['txtName'],
				'author'=>$_REQUEST['txtAuthor'],
				'about'=>$_REQUEST['txtAbout'],
				'book_image'=>$_REQUEST['image_name']
			),

			array(
				'id'=>$_REQUEST['book_id']
			)
		);

		echo json_encode(array('status'=>1,'message'=>'Book updated sucessfully'));
	}

	elseif ($_REQUEST['param'] == 'delete_book') {

		$wpdb->delete(my_books_table(),array('id'=>$_REQUEST['id']));
		echo json_encode(array('status'=>1,'message'=>'Book deleted sucessfully'));

	}
	elseif ($_REQUEST['param'] == 'save_author') {
	
		$wpdb->insert(my_authors_table(),
			array(

				'name'=>$_REQUEST['txtName'],
				'fb_link'=>$_REQUEST['txtfb_link'],
				'about'=>$_REQUEST['txtAbout']
			)
		);

		echo json_encode(array('status'=>1,'message'=>'Author created sucessfully'));

	}
	elseif ($_REQUEST['param'] == 'delete_author') {

		$wpdb->delete(my_authors_table(),array('id'=>$_REQUEST['id']));
		echo json_encode(array('status'=>1,'message'=>'Autho deleted sucessfully'));

	}
	elseif ($_REQUEST['param'] == 'save_student') {
	
		//please check user is exits or not username_exists($_REQUEST['txtuserName'])
		//please check email is exits or not email_exists($_REQUEST['txtEmail'])

		//create new user in wp_users (in built function)
		if(!username_exists($_REQUEST['txtuserName']) && !email_exists($_REQUEST['txtEmail'])){
			$student_id  = wp_create_user($_REQUEST['txtuserName'],$_REQUEST['txtPassword'],$_REQUEST['txtEmail']);
			$user_id = $student_id;

			//set user role dynamically
			$user = new WP_User($student_id);
			$user->set_role('wp_book_user_key');

			$wpdb->insert(my_students_table(),
				array(

					'name'=>$_REQUEST['txtName'],
					'email'=>$_REQUEST['txtEmail'],
					'user_login_id'=>$user_id
				)
			);

			echo json_encode(array('status'=>1,'message'=>'Student created sucessfully'));
		}
		else
		{
			echo json_encode(array('status'=>1,'message'=>'Student already exists'));	
		}

	}
	elseif ($_REQUEST['param'] == 'delete_student') {

		$student_detail = $wpdb->get_row(

						$wpdb->prepare(
							"select * from ".my_students_table()." where id = %d",$_REQUEST['id']
						),ARRAY_A
				   );
		if(!empty($student_detail['user_login_id'])){

			wp_delete_user($student_detail['user_login_id']);	
		}

		$wpdb->delete(my_students_table(),array('id'=>$_REQUEST['id']));
		
		echo json_encode(array('status'=>1,'message'=>'Student deleted sucessfully'));

	}
	elseif ($_REQUEST['param'] == 'save_enrole') {

		$student_detail = $wpdb->get_row(

						$wpdb->prepare(
							"select * from ".my_students_table()." where user_login_id = %d",$_REQUEST['userid']
						),ARRAY_A
				   );

		$wpdb->insert(my_enrol_table(),
				array(

					'student_id'=>$student_detail['id'],
					'book_id'=>$_REQUEST['book_id']
				)
			);

			echo json_encode(array('status'=>1,'message'=>'Enrol created sucessfully'));		   
		
	}
	
?>