jQuery(document).ready(function() {

	//upload images
	jQuery('#btn-upload').on('click',function(){

		var image = wp.media({

			title:'Upload Image for My Book',
			multiple:false
		}).open().on('select',function(){

			 var uploaded_image = image.state().get('selection').first();
			 var getImage = uploaded_image.toJSON().url;

			 jQuery('#show-image').html('<img src="'+getImage+'" style="height:50px;width:50px;"/>');
			 jQuery('#image_name').val(getImage);
		});
	});


	//data table
   jQuery('#my-book').DataTable();

   //Add book 
   jQuery('#frmAddBook').validate({

   		submitHandler: function(){
   			var post_data = "action=mybooklibrary&param=save_book&"+jQuery('#frmAddBook').serialize();

   			jQuery.post(mybookajaxurl,post_data,function(response){

   				var data = jQuery.parseJSON(response);
   				
   				if(data.status == 1){
   					jQuery.notifyBar({
   						cssClass:'success',
   						html:data.message
   					});
   				}
   				else{

   				}

   			});
   		}
   });

   //Edit book
   jQuery('#frmEditBook').validate({

   		submitHandler: function(){
   			var post_data = "action=mybooklibrary&param=edit_book&"+jQuery('#frmEditBook').serialize();

   			jQuery.post(mybookajaxurl,post_data,function(response){

   				var data = jQuery.parseJSON(response);
   				
   				if(data.status == 1){

   					jQuery.notifyBar({
   						cssClass:'success',
   						html:data.message
   					});

   					setTimeout(function(){
   						//window.location.reload();
   						location.reload();

   					},1300);
   				}
   				else{

   				}

   			});
   		}

   });

   //deleted recode form table
   jQuery(document).on('click','.btnbookdelete',function(){

   	    var conf = confirm('Are you sure to delete this recored?');
   	    if(conf){

	   		var book_id = jQuery(this).attr('data-id');

	   		var post_data = "action=mybooklibrary&param=delete_book&id="+book_id;

	   			jQuery.post(mybookajaxurl,post_data,function(response){

	   				var data = jQuery.parseJSON(response);
	   				
	   				if(data.status == 1){
	   					jQuery.notifyBar({
	   						cssClass:'success',
	   						html:data.message
	   					});

	   					setTimeout(function(){
	   						location.reload()
	   					},1300);
	   				}
	   				else{

	   				}

	   			});
	   		}	

    });

   //Add Author Data
   jQuery('#frmAddAuthor').validate({

      submitHandler: function(){
            var post_data = "action=mybooklibrary&param=save_author&"+jQuery('#frmAddAuthor').serialize();

            jQuery.post(mybookajaxurl,post_data,function(response){

               var data = jQuery.parseJSON(response);
               
               if(data.status == 1){
                  jQuery.notifyBar({
                     cssClass:'success',
                     html:data.message
                  });
               }
               else{

               }

            });
         }

   });

   //deleted Author recode
   jQuery(document).on('click','.btnauthordelete',function(){

          var conf = confirm('Are you sure to delete this recored?');
          if(conf){

            var book_id = jQuery(this).attr('data-id');

            var post_data = "action=mybooklibrary&param=delete_author&id="+book_id;

               jQuery.post(mybookajaxurl,post_data,function(response){

                  var data = jQuery.parseJSON(response);
                  
                  if(data.status == 1){
                     jQuery.notifyBar({
                        cssClass:'success',
                        html:data.message
                     });

                     setTimeout(function(){
                        location.reload()
                     },1300);
                  }
                  else{

                  }

               });
            }  

    });

    //Add New Student
    
    jQuery('#frmAddStudent').validate({

         submitHandler: function(){

            var post_data = "action=mybooklibrary&param=save_student&"+jQuery('#frmAddStudent').serialize();

            jQuery.post(mybookajaxurl,post_data,function(response){

               var data = jQuery.parseJSON(response);
               
               if(data.status == 1){
                  jQuery.notifyBar({
                     cssClass:'success',
                     html:data.message
                  });
               }
               else{

               }

            });

         }
    });  

    //deleted student recode
   jQuery(document).on('click','.btnstudentdelete',function(){

          var conf = confirm('Are you sure to delete this recored?');
          if(conf){

            var book_id = jQuery(this).attr('data-id');

            var post_data = "action=mybooklibrary&param=delete_student&id="+book_id;

               jQuery.post(mybookajaxurl,post_data,function(response){

                  var data = jQuery.parseJSON(response);
                  
                  if(data.status == 1){
                     jQuery.notifyBar({
                        cssClass:'success',
                        html:data.message
                     });

                     setTimeout(function(){
                        location.reload()
                     },1300);
                  }
                  else{

                  }

               });
            }  

    });

   //Enrole Code
   jQuery(document).on('click','.owt-enrol-btn',function(){

      var current_user_id = jQuery(this).attr('data-user-id');
      var book_id = jQuery(this).attr('data-book-id');

      var post_data = "action=mybooklibrary&param=save_enrole&book_id="+book_id+"&userid="+current_user_id;

         jQuery.post(mybookajaxurl,post_data,function(response){

            //console.log(response);
            var data = jQuery.parseJSON(response);
            
            if(data.status == 1){
               jQuery.notifyBar({
                  cssClass:'success',
                  html:data.message
               });

               setTimeout(function(){
                  location.reload()
               },1300);
            }
            else{

            }

         });

   });

} );