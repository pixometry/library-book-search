<?php
/*
Plugin Name: My Book
Description: This is my custom plugin which basically make use of books management
Plugin URI: http://www.wordpress.org
Author: Trushal Makwana
Author URI: http://www.wordpress.org
Version: 1.0
*/

if(!defined('ABSPATH'))
	exit;

if(!defined('MY_BOOK_PLUGIN_DIR_PATH'))
	define('MY_BOOK_PLUGIN_DIR_PATH', plugin_dir_path(__FILE__));

if(!defined('MY_BOOK_PLUGIN_URL'))
	define('MY_BOOK_PLUGIN_URL', plugins_url().'/my-books');

//add js and css file
function my_book_include_assets(){

	$slug = '';
	$pages_includes = array('book-list','add-new','add-author','remove-author','add-student','remove-student','course-tracker','my-book-page','frontendpage');
	$currentPage = $_GET['page'];

	if(empty($currentPage)){

		$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

		if(preg_match('/my-book-page/', $actual_link)){

			$currentPage = 'frontendpage';
		}
	}

	if(in_array($currentPage, $pages_includes)){

		//css files
		wp_enqueue_style('bootstrap.min',MY_BOOK_PLUGIN_URL.'/assets/css/bootstrap.min.css','');
		wp_enqueue_style('jquery.dataTables',MY_BOOK_PLUGIN_URL.'/assets/css/jquery.dataTables.css','');
		wp_enqueue_style('jquery.notifyBar',MY_BOOK_PLUGIN_URL.'/assets/css/jquery.notifyBar.css','');
		wp_enqueue_style('style',MY_BOOK_PLUGIN_URL.'/assets/css/style.css','');

		//scripts file
		wp_enqueue_script('jquery');
		wp_enqueue_script('bootstrap.min',MY_BOOK_PLUGIN_URL.'/assets/js/bootstrap.min.js','',true);
		wp_enqueue_script('jquery.dataTables',MY_BOOK_PLUGIN_URL.'/assets/js/jquery.dataTables.js','',true);
	    wp_enqueue_script('jquery.notifyBar',MY_BOOK_PLUGIN_URL.'/assets/js/jquery.notifyBar.js','',true);
	    wp_enqueue_script('jquery.validate.min',MY_BOOK_PLUGIN_URL.'/assets/js/jquery.validate.min.js','',true);
		wp_enqueue_script('script',MY_BOOK_PLUGIN_URL.'/assets/js/script.js','',true);
		wp_localize_script('script','mybookajaxurl',admin_url('admin-ajax.php'));

	}
	
}
add_action('init','my_book_include_assets');

//add menu
function my_book_plugin_menus(){

	add_menu_page('My Book','My Book','manage_options','book-list','my_book_list','dashicons-book',30);
	add_submenu_page('book-list','Book List','Book List','manage_options','book-list','my_book_list');
	add_submenu_page('book-list','Add New','Add New','manage_options','add-new','my_book_add');
	add_submenu_page('book-list','','','manage_options','book-edit','my_book_edit');

	add_submenu_page('book-list','Add New Author','Add New Author','manage_options','add-author','my_author_add');
	add_submenu_page('book-list','Manage Author','Manage Author','manage_options','remove-author','my_author_remove');
	add_submenu_page('book-list','Add New Student','Add New Student','manage_options','add-student','my_student_add');
	add_submenu_page('book-list','Manage Student','Manage Student','manage_options','remove-student','my_student_remove');

	add_submenu_page('book-list','Course Tracker','Course Tracker','manage_options','course-tracker','course_tracker');


}
add_action('admin_menu','my_book_plugin_menus');

function my_author_add(){

	include_once MY_BOOK_PLUGIN_DIR_PATH.'/views/author-add.php';

}

function my_author_remove(){

	include_once MY_BOOK_PLUGIN_DIR_PATH.'/views/manage-author.php';

}

function my_student_add(){

	include_once MY_BOOK_PLUGIN_DIR_PATH.'/views/student-add.php';

}

function my_student_remove(){

	include_once MY_BOOK_PLUGIN_DIR_PATH.'/views/manage-student.php';

}

function course_tracker(){

	include_once MY_BOOK_PLUGIN_DIR_PATH.'/views/course-tracker.php';

}

function my_book_list(){

	include_once MY_BOOK_PLUGIN_DIR_PATH.'/views/book-list.php';
}

function my_book_add(){

	include_once MY_BOOK_PLUGIN_DIR_PATH.'/views/book-add.php';
}

function my_book_edit(){
	
	include_once MY_BOOK_PLUGIN_DIR_PATH.'/views/book-edit.php';	
}

//create table name
function my_books_table(){

	global $wpdb;

	$table_name = $wpdb->prefix.'my_books';

	return $table_name;	
}

function my_authors_table(){

	global $wpdb;

	$table_name = $wpdb->prefix.'my_authors';

	return $table_name;	
}

function my_students_table(){

	global $wpdb;

	$table_name = $wpdb->prefix.'my_students';

	return $table_name;	
}

function my_enrol_table(){

	global $wpdb;

	$table_name = $wpdb->prefix.'my_enrol';

	return $table_name;	
}

//create database
function my_book_create_table(){

	global $wpdb;

	require_once(ABSPATH.'wp-admin/includes/upgrade.php');

	if( count($wpdb->get_var('SHOW TABLES LIKE "'.my_books_table().'"')) == 0 ){
		$sql_books = "CREATE TABLE IF NOT EXISTS `".my_books_table()."` (
						  `id` int(11) NOT NULL AUTO_INCREMENT,
						  `name` varchar(50) NOT NULL,
						  `author` varchar(255) NOT NULL,
						  `about` text NOT NULL,
						  `book_image` text NOT NULL,
						  `create_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
						  PRIMARY KEY (`id`)
					  ) ENGINE=MyISAM DEFAULT CHARSET=latin1";

		dbDelta($sql_books);							  
	}

	

	if( count($wpdb->get_var('SHOW TABLES LIKE "'.my_authors_table().'"')) == 0 ){
		$sql_authors = "CREATE TABLE `".my_authors_table()."` (
						 `id` int(11) NOT NULL AUTO_INCREMENT,
						 `name` varchar(255) DEFAULT NULL,
						 `fb_link` text,
						 `about` text,
						 `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
						 PRIMARY KEY (`id`)
						) ENGINE=MyISAM DEFAULT CHARSET=latin1";

		dbDelta($sql_authors);
						
	}

	if( count($wpdb->get_var('SHOW TABLES LIKE "'.my_students_table().'"')) == 0 ){
		$sql_students = "CREATE TABLE `".my_students_table()."` (
						 `id` int(11) NOT NULL AUTO_INCREMENT,
						 `name` varchar(255) DEFAULT NULL,
						 `email` varchar(255) DEFAULT NULL,
						 `user_login_id` int(11) DEFAULT NULL,
						 `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
						 PRIMARY KEY (`id`)
						) ENGINE=MyISAM DEFAULT CHARSET=latin1";
						
		dbDelta($sql_students);
						
	}

	if( count($wpdb->get_var('SHOW TABLES LIKE "'.my_enrol_table().'"')) == 0 ){
		$sql_enrol = "CREATE TABLE `".my_enrol_table()."` (
						 `id` int(11) NOT NULL AUTO_INCREMENT,
						 `student_id` int(11) NOT NULL,
						 `book_id` int(11) NOT NULL,
						 `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
						 PRIMARY KEY (`id`)
						) ENGINE=MyISAM DEFAULT CHARSET=latin1";
						
		dbDelta($sql_enrol);
						
	}

	//user role registration 
	add_role('wp_book_user_key','My Book User',array('read'=>true));

	//dynamic page creation code
	$my_post = array(
	  'post_title'    => 'My Book Page',
	  'post_content'  => "[book_page]",
	  'post_status'   => 'publish',
	  'post_type'	  => 'page',
	  'post_name'	  => 'my-book-page',

	);

	// Insert the post into the database
	$bookid = wp_insert_post( $my_post );

	//add data in option table
	add_option('my_book_page_id',$bookid);


}
register_activation_hook(__FILE__,'my_book_create_table');

//create short code

function my_book_page_fns(){

	include_once MY_BOOK_PLUGIN_DIR_PATH.'/views/my_book_frontend_list.php';
}

add_shortcode('book_page','my_book_page_fns');

//drop table from tabase
function my_book_delete_table(){
  
   	global $wpdb;
   	$wpdb->query("DROP TABLE IF EXISTS `".my_books_table()."`");
   	$wpdb->query("DROP TABLE IF EXISTS `".my_authors_table()."`");
   	$wpdb->query("DROP TABLE IF EXISTS `".my_students_table()."`");
   	$wpdb->query("DROP TABLE IF EXISTS `".my_enrol_table()."`");

   	//remove user role
   	if(get_role('wp_book_user_key')){

   		remove_role('wp_book_user_key');	
   	}
   	
   	//delete the page

   	if(!empty(get_option('my_book_page_id'))){

   		$pageid = get_option('my_book_page_id');
   		wp_delete_post($pageid,true);
   		delete_option('my_book_page_id');

   	}

}
register_deactivation_hook(__FILE__,'my_book_delete_table');
//register_uninstall_hook(__FILE__,'my_book_delete_table');

//insert data using ajax code
add_action('wp_ajax_mybooklibrary','my_book_ajax_handler');

function my_book_ajax_handler(){

	global $wpdb;
	include_once MY_BOOK_PLUGIN_DIR_PATH.'/library/my_book_library.php';
	wp_die();
}

//create custom page template
add_filter('page_template','owt_custom_page_layout');

function owt_custom_page_layout($page_template){

	global $post;

	$page_slug = $post->post_name; //book page slug

	if($page_slug == 'my-book-page'){

		$page_template = MY_BOOK_PLUGIN_DIR_PATH.'/views/frontend-book-template.php';
	}
	return $page_template;

}

//get all detals of author base on author id
function get_author_details($author_id){

	global $wpdb;
	$author_details = $wpdb->get_row(

						$wpdb->prepare(

							"select * from ".my_authors_table()." where id = %d", $author_id	
						),ARRAY_A
					  );
	return $author_details;

}

//user login filter
function qwt_login_user_role_filter($redirect_to,$request,$user){

	//custom user role
	global $user;

	if(isset($user->roles) && is_array($user->roles)){

		if(in_array('wp_book_user_key', $user->roles)){

				$redirect_to = site_url().'/my-book-page';

				return $redirect_to;
		}
		else
		{
			return $redirect_to;
		}
	}
}

add_filter('login_redirect','qwt_login_user_role_filter',10,3);

function qwt_logout_user_role_filter(){

	//custom user role
	wp_redirect(site_url().'/my-book-page');
	exit();
}
add_filter('wp_logout','qwt_logout_user_role_filter');