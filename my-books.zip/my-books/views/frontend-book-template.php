<?php
/*
	Template Name : Front End Book Page Layout
*/
get_header();	
?>

<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<div class="alert alert-info" style="background-color: #d3f582 !important;">
				<h3>OWT COURSE</h3>
			</div>
			<?php 

			echo do_shortcode('[book_page]');

			?>
		</div>
	</div>
</div>

<?php 
get_footer();
?>