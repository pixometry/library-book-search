<?php wp_enqueue_media(); ?>
<div class="container">
	
	<div class="alert alert-info">
         <h5>Book Add Page</h5>
    </div>

	<div class="panel panel-default">
	  <div class="panel-heading">Add New Book</div>
	  <div class="panel-body">
	  	<form class="form-horizontal" action="javascript:void(0);" id="frmAddBook">

  		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtName">Name:</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="txtName" name="txtName" placeholder="Enter Name" required="required">
		  	</div>
		  </div>

		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtAuthor">Author:</label>
		    <div class="col-sm-10">
		      <!--<input type="text" class="form-control" id="txtAuthor" name="txtAuthor" placeholder="Enter Author Name" required="required">-->
		      
		      <select name="txtAuthor" id="txtAuthor" class="form-control">
		      	<option value="-1">-- Choose Author --</option>
		      	<?php 
				global $wpdb;

				$all_authors_option = $wpdb->get_results(

				                $wpdb->prepare(
				                    "select * from ".my_authors_table()." order by id desc",""
				                ),ARRAY_A
				            );

				if(count($all_authors_option) > 0)
				foreach ($all_authors_option as $key => $value) {
					
					?>
					<option value="<?php echo $value['id'] ?>"><?php echo $value['name'] ?></option>
					<?php
				}

				?>

		      </select>
		  	</div>
		  </div>

		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtAbout">About:</label>
		    <div class="col-sm-10">
		      <textarea id="txtAbout" name="txtAbout" placeholder="Enter About" class="form-control"></textarea>
		  	</div>
		  </div>

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="btn-upload">Upload Book Image:</label>
		    <div class="col-sm-10">
		      <input type="button" class="btn btn-info" value="Upload Image" id="btn-upload" name="btn-upload">
		      <span id="show-image"></span>
		      <input type="hidden" name="image_name" id="image_name">
		    </div>
		  </div>

		  <div class="form-group"> 
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default">Submit</button>
		    </div>
		  </div>
		</form>
	  </div>
	</div>
</div>