<?php 

global $wpdb;

$all_students = $wpdb->get_results(

                $wpdb->prepare(
                    "select * from ".my_students_table()." order by id desc",""
                ),ARRAY_A
            );

?>
<div class="container">

    <div class="alert alert-info">
         <h5>My Student List</h5>
    </div>
    <div class="panel panel-primary">
      <div class="panel-heading">My Student List</div>
      <div class="panel-body">
          <table id="my-book" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>Sr.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>User Name</th>
                    <th>Created At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                if(count($all_students) > 0){

                    $i=1;
                    foreach ($all_students as $key => $value) {

                        $userdetails = get_userdata($value['user_login_id']);

                        ?>

                        <tr>
                            <td><?php echo $i++; ?></td>
                            <td><?php echo $value['name']; ?></td>
                            <td><?php echo $value['email']; ?></td>
                            <td><?php echo $userdetails->user_login; ?></td>
                            <td><?php echo $value['created_at']; ?></td>
                            <td>
                                <!--<a class="btn btn-info" href="admin.php?page=remove-student&edit=<?php //echo $value['id']; ?>">Edit</a>-->
                                <a class="btn btn-danger btnstudentdelete" href="javascript:void(0);" data-id="<?php echo $value['id']; ?>">Delete</a>
                            </td>
                        </tr>

                        <?php
                        
                    }
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Sr.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>User Name</th>
                    <th>Created At</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>
      </div>
    </div>
    
</div>