<div class="container">
	
	<div class="alert alert-info">
         <h5>Student Add Page</h5>
    </div>

	<div class="panel panel-default">
	  <div class="panel-heading">Add New Student</div>
	  <div class="panel-body">
	  	<form class="form-horizontal" action="javascript:void(0);" id="frmAddStudent">

  		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtName">Name:</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="txtName" name="txtName" placeholder="Enter Name" required="required">
		  	</div>
		  </div>

		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtEmail">Email Address:</label>
		    <div class="col-sm-10">
		      <input type="email" class="form-control" id="txtEmail" name="txtEmail" placeholder="Enter Email" required="required">
		  	</div>
		  </div>

		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtuserName">User Name:</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="txtuserName" name="txtuserName" placeholder="Enter User Name" required="required">
		  	</div>
		  </div>

		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtPassword">Password:</label>
		    <div class="col-sm-10">
		      <input type="password" class="form-control" id="txtPassword" name="txtPassword" placeholder="Enter Password" required="required">
		  	</div>
		  </div>

		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtconfPassword">Conform Password:</label>
		    <div class="col-sm-10">
		      <input type="password" class="form-control" id="txtconfPassword" name="txtconfPassword" placeholder="Enter Conform Password" required="required">
		  	</div>
		  </div>

		  <div class="form-group"> 
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default">Submit</button>
		    </div>
		  </div>
		</form>
	  </div>
	</div>
</div>