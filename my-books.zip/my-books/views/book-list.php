<?php 

global $wpdb;

$all_books = $wpdb->get_results(

                $wpdb->prepare(
                    "select * from ".my_books_table()." order by id desc",""
                ),ARRAY_A
            );

?>
<div class="container">

    <div class="row">
        <div class="alert alert-info">
             <h5>My Book List</h5>
        </div>
        <div class="panel panel-primary">
          <div class="panel-heading">My Book List</div>
          <div class="panel-body">
              <table id="my-book" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Sr.</th>
                        <th>Name</th>
                        <th>Author</th>
                        <th>About</th>
                        <th>Book Image</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if(count($all_books) > 0){

                        $i=1;
                        foreach ($all_books as $key => $value) {

                            ?>

                            <tr>
                                <td><?php echo $i++; ?></td>
                                <td><?php echo $value['name']; ?></td>
                                <td><?php echo $value['author']; ?></td>
                                <td><?php echo $value['about']; ?></td>
                                <td><img src="<?php echo $value['book_image']; ?>" style="height: 80px;width: 80px;"></td>
                                <td><?php echo $value['create_at']; ?></td>
                                <td>
                                    <a class="btn btn-info" href="admin.php?page=book-edit&edit=<?php echo $value['id']; ?>">Edit</a>
                                    <a class="btn btn-danger btnbookdelete" href="javascript:void(0);" data-id="<?php echo $value['id']; ?>">Delete</a>
                                </td>
                            </tr>

                            <?php
                            
                        }
                    }
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Sr.</th>
                        <th>Name</th>
                        <th>Author</th>
                        <th>About</th>
                        <th>Book Image</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
            </table>
          </div>
        </div>
        
    </div>
</div>