<div class="container">
	
	<div class="alert alert-info">
         <h5>Author Add Page</h5>
    </div>

	<div class="panel panel-default">
	  <div class="panel-heading">Add New Author</div>
	  <div class="panel-body">
	  	<form class="form-horizontal" action="javascript:void(0);" id="frmAddAuthor">

  		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtName">Name:</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="txtName" name="txtName" placeholder="Enter Name" required="required">
		  	</div>
		  </div>

		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtfb_link">FB Link:</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="txtfb_link" name="txtfb_link" placeholder="Enter FaceBook URL" required="required">
		  	</div>
		  </div>

		  <div class="form-group">
	    	<label class="control-label col-sm-2" for="txtAbout">About:</label>
		    <div class="col-sm-10">
		      <textarea id="txtAbout" name="txtAbout" placeholder="Enter About" class="form-control"></textarea>
		  	</div>
		  </div>

		  <div class="form-group"> 
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default">Submit</button>
		    </div>
		  </div>
		</form>
	  </div>
	</div>
</div>